package projetFinal;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import models.Bloc;
import models.Note;
import models.Student;
import models.program;

public class XMLtools {
	

	public static List<models.Student> getStudents(){	
        try {
    		List<models.Student> students = new  ArrayList<>();
            File file = new File("C:\\Users\\33671\\Desktop\\data.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(file); // ouverture et lecture du fichier XML
            doc.getDocumentElement().normalize(); // normalise le contenu du fichier, op�ration tr�s conseill�e
            Element root = doc.getDocumentElement(); // la racine de l'arbre XML
            List<Element> elements=getChildren(doc.getDocumentElement(), "student");
            for (int i=0;i<elements.size();i++) {
            	Element e=elements.get(i);
            	int identifier=Integer.parseInt(e.getElementsByTagName("identifier").item(0).getTextContent());
            	String name=e.getElementsByTagName("name").item(0).getTextContent();
            	String surname=e.getElementsByTagName("surname").item(0).getTextContent();
            	String programme=e.getElementsByTagName("program").item(0).getTextContent();
            	Student student=new models.Student(identifier,name,surname,programme);
                List<Element> gradesElement=getChildren(e, "grade");
                for(int j=0;j<gradesElement.size();j++) {
                	Element g=gradesElement.get(j);
                	String code=g.getElementsByTagName("item").item(0).getTextContent();
                	String value=g.getElementsByTagName("value").item(0).getTextContent();
                	student.addNote(new Note(code,value));
                }
                students.add(student);
            }  
            return students;

            
        } catch (Exception e) {
    		List<models.Student> students = new  ArrayList<>();
            return students;

        }

	}
	
	public static List<models.program> getProgramList(){	
        try {
    		List<models.program> programs = new  ArrayList<>();
            File file = new File("C:\\Users\\33671\\Desktop\\data.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(file); // ouverture et lecture du fichier XML
            doc.getDocumentElement().normalize(); // normalise le contenu du fichier, op�ration tr�s conseill�e
            Element root = doc.getDocumentElement(); // la racine de l'arbre XML
            List<Element> elements=getChildren(doc.getDocumentElement(), "program");
            for (int i=0;i<elements.size();i++) {
            	Element e=elements.get(i);
            	//create bloc liste :
            	List<Bloc> blocs= new ArrayList<>();
            	//bloc simple:
            	List<Element> elementsbloc=getChildren(e, "item");
            	   for (Element el:elementsbloc) {
            		  blocs.add(getCours(el.getTextContent()));
            		   
            	   }
            	
            	      
            	//bloc a option 
            	//bloc composite 
            	
     
            	//*****************************************
            	String identifier=e.getElementsByTagName("identifier").item(0).getTextContent();
            	String name=e.getElementsByTagName("name").item(0).getTextContent();
                programs.add(new models.program(identifier,name,blocs));
            }  
            return programs;

            
        } catch (Exception e) {
    		List<models.program> programs = new  ArrayList<>();
            return programs;

        }

	}
	
	
	public static List<models.Bloc> getCoursListe(){	
        try {
    		List<models.Bloc> cours = new  ArrayList<>();
            File file = new File("C:\\Users\\33671\\Desktop\\data.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(file); // ouverture et lecture du fichier XML
            doc.getDocumentElement().normalize(); // normalise le contenu du fichier, op�ration tr�s conseill�e
            Element root = doc.getDocumentElement(); // la racine de l'arbre XML
            List<Element> elements=getChildren(doc.getDocumentElement(), "course");
            for (int i=0;i<elements.size();i++) {
            	Element e=elements.get(i);
            	
            	String identifier=e.getElementsByTagName("identifier").item(0).getTextContent();
            	String name=e.getElementsByTagName("name").item(0).getTextContent();
            	int credits=Integer.parseInt( e.getElementsByTagName("credits").item(0).getTextContent());
                cours.add(new models.Bloc(identifier,name,credits));
            }  
            return cours;

            
        } catch (Exception e) {
    		List<models.Bloc> cours = new  ArrayList<>();
            return cours;
        }

	}
	
	public static Bloc getCours(String identifier) {
		List<Bloc> list=getCoursListe();
		 for (Bloc b:list) {
			 if (b.getCode()== identifier) return b;
		 }
		 return list.get(0);
	}
	public static Student getStudent(int identifier) {
		List<Student> list=getStudents();
		 for (Student s:list) {
			 if (s.getIdentifier()== identifier) return s;
		 }
		 return list.get(0);
	}
	
	public static program getProgram(String identifier) {
		List<program> list=getProgramList();
		 for (program b:list) {
			 if (b.getIdentifier()== identifier) return b;
		 }
		 return list.get(0);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    
    
    private static  List<Element> getChildren(Element item, String name) {
        NodeList nodeList = item.getChildNodes();
        List<Element> children = new ArrayList<>();
        for (int i = 0; i < nodeList.getLength(); i++) {
            Node node = nodeList.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) nodeList.item(i); // cas particulier pour nous o� tous les noeuds sont des �l�ments
                if (element.getTagName().equals(name)) {
                    children.add(element);
                }
            }
        }
        return children;
    }
}


