package projetFinal;
import java.awt.GridLayout;
import java.util.List;

import javax.swing.*;

import GUI.Jalon1;
public class main {
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     JFrame jframe= new JFrame("projet POfO");
     JTabbedPane tp = new JTabbedPane();
      new Jalon1(tp);
     jframe.add(tp);
     jframe.setVisible(true);

	}

}
