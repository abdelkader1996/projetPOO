package GUI;

import java.awt.GridLayout;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;

import models.Bloc;
import projetFinal.XMLtools;

public class Jalon1 extends JPanel{	
	public Jalon1(JTabbedPane tp){
		String[] columnNames = {"identifier",
	            "name",
	            "surname",
	            "program"
	              };
		List<Bloc> coursliste=XMLtools.getCoursListe();
		String[] columns= new String[columnNames.length+coursliste.size()];
		columns[0]=columnNames[0];
		columns[1]=columnNames[1];
		columns[2]=columnNames[2];
		columns[3]=columnNames[3];
		
		for (int i=4 ;i<columns.length ;i++) {
			columns[i]=coursliste.get(i-4).getCode();
		}

		List<models.Student> students= XMLtools.getStudents();
		String[][] data;
		System.out.println("jamon1 constructor ");
		data =new  String[students.size()+4][columns.length];
		
		for (int i=0 ;i<students.size();i++) {
			data[i][0]=students.get(i).getIdentifier()+"";
			data[i][1]=students.get(i).getName();
			data[i][2]=students.get(i).getSurname();
			data[i][3]=students.get(i).getProgramme();
			for (int j=4 ;j<columns.length;j++) {
				data[i][j]=students.get(i).getNote(columns[j]);
			}
			
		}
		data=calculeDesMoyennes(data);
		data=calculeDesMaxMin(data);
		data=calculeDesEcartTypes(data);

		
		
	     GridLayout gridlayout =new GridLayout();
	     this.setLayout(gridlayout);
	     JTable table = new JTable(data, columns);
	     JScrollPane scrollPane = new JScrollPane(table);
	     this.add(scrollPane);
			System.out.println("fin  constructor ");
			tp.add("jalon1 ",this);

		
	}
	
	private String[][]  calculeDesMoyennes(String[][] data) {
		String[][] result=data;
		for (int j=4;j<data[0].length;j++) {
			double acc=0;
			int m=0;
			for(int i=0;i<data.length;i++) {
				if(result[i][j]!=null) {
				if (!result[i][j].equals(" ") && (!result[i][j].equals("ABI"))) {
					acc+=Double.parseDouble(data[i][j]);
					m+=1;}}
			}
			 result[data.length-2][j]=(acc/m)+"";
		}
		 result[data.length-2][0]="    MOYENNE";
		 return result;

	}
	private String[][]  calculeDesMaxMin(String[][] data) {
		String[][] result=data;
		for (int j=4;j<data[0].length;j++) {
			double max=0;
			double min=20;
			for(int i=0;i<data.length;i++) {
				if(result[i][j]!=null) {
				if (!result[i][j].equals(" ") && (!result[i][j].equals("ABI"))) {
					max=Double.parseDouble(data[i][j])>max?Double.parseDouble(data[i][j]):max;
					min=Double.parseDouble(data[i][j])<min?Double.parseDouble(data[i][j]):min;
					}}
			}
			 result[data.length-4][j]=max+"";
			 result[data.length-3][j]=min+"";

		}
		 result[data.length-4][0]="    MAX";
		 result[data.length-3][0]="    MIN";

		 return result;

	}
	private String[][]  calculeDesEcartTypes(String[][] data) {
		String[][] result=data;
		for (int j=4;j<data[0].length;j++) {
			double acc=0;
			int m=0;
			for(int i=0;i<data.length;i++) {
				if(result[i][j]!=null) {
				if (!result[i][j].equals(" ") && (!result[i][j].equals("ABI"))) {
					acc+=Math.pow(Double.parseDouble(data[i][j])-Double.parseDouble(data[data.length-2][j]),2);
					m+=1;}}
			}
			 result[data.length-1][j]=Math.sqrt(acc/m)+"";
		}
		 result[data.length-1][0]="    Ecart Type:";
		 return result;
}
}