package models;

import java.util.ArrayList;
import java.util.List;

public class Student {
	private int identifier; 
	private String name;
	private String surname;
	private String programme;
	private List<Note> notes;
	public Student(int identifier,String name,	String surname,	String programme){
		this.setIdentifier(identifier);
		this.setName(name);
		this.setSurname(surname);
		this.setProgramme(programme);
		this.notes=new ArrayList<>();
	}
	public void addNote(Note note) {
		this.notes.add(note);
	}
	public String getNote(String code) {
		for (Note n:notes) {
			if(n.getBlocCode().compareTo(code)==0) return n.getValue();
		}
		return " ";
		
	}
	public int getIdentifier() {
		return identifier;
	}
	public void setIdentifier(int identifier) {
		this.identifier = identifier;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSurname() {
		return surname;
	}
	public void setSurname(String surname) {
		this.surname = surname;
	}
	public String getProgramme() {
		return programme;
	}
	public void setProgramme(String programme) {
		this.programme = programme;
	}
	public void printNotes() {
		System.out.print("print notes");
		for(Note n:this.notes) System.out.println(n.getBlocCode()+"-"+n.getValue());
	}

}
