package models;

public class BlocAOptions extends Bloc {
	
    private Bloc[] cours;
	public BlocAOptions(String nom, String code, int credits,Bloc[] cours) {
		super(nom, code, cours[0].getCredits());
		this.cours=cours;
	}
	public Bloc[] getCours() {
		return cours;
	}
	
}
