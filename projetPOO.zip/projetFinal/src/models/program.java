package models;

import java.util.List;

public class program {
	private String identifier;
	String name;
	private List<Bloc> blocs;
	 public program(String identifier,String name,List<Bloc> blocs) {
		 this.identifier=identifier;
		 this.name=name;
		 this.blocs=blocs;
	 }
	public List<Bloc> getBlocs() {
		return blocs;
	}
	public String getIdentifier() {
		return identifier;
	}
	
	public String toString() {
		String cx="";
		for (Bloc c: blocs) 
			cx+=c.getCode()+"///";		
	
	return cx;
}
	

}
