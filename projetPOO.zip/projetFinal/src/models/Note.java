package models;

public class Note {
	private String blocCode;
	private String value;
	public Note(String blocCode,String value) {
		this.blocCode=blocCode;
		this.value=value;
	}
	public String getBlocCode() {
		return blocCode;
	}
	public String getValue() {
		return value;
	}
	

}
