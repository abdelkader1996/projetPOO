package models;

public class Bloc {
	private String code;
	private int credits;
	private String nom;
	
	public Bloc(String code,String nom,int credits){
		this.setNom(nom);
		this.setCode(code);
		this.setCredits(credits);
}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public int getCredits() {
		return credits;
	}
	public void setCredits(int credits) {
		this.credits = credits;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	public Bloc[] getCours() {
		Bloc[] blocs= new Bloc[1];
		blocs[0]=this;
		return blocs;
	}
}
