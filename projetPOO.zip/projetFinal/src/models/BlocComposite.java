package models;

public class BlocComposite extends Bloc {

    private Bloc[] cours;
	public BlocComposite(String nom, String code, int credits,Bloc[] cours) {
		super(nom, code, 0);
		this.cours=cours;
		int cr=0;
		for (Bloc c:cours) {
			cr+=c.getCredits();
		}
		this.setCredits(cr);
		}
	public Bloc[] getCours() {
		return cours;
	}


}
